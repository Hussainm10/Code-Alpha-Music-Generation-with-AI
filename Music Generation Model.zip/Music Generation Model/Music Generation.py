import os
import numpy as np
from music21 import converter, instrument, note, chord, stream
from keras.models import Sequential, load_model
from keras.layers import LSTM, Dense, Dropout
from keras.utils import to_categorical

# Define paths and parameters
midi_folder_path = r"C:\Users\sg\Downloads\Music Generation Process\midi_files"
sequence_length = 100

def load_midi_files(midi_folder_path):
    notes = []
    for file in os.listdir(midi_folder_path):
        if file.endswith(".mid"):
            midi = converter.parse(os.path.join(midi_folder_path, file))
            notes_to_parse = None
            try:
                parts = instrument.partitionByInstrument(midi)
                notes_to_parse = parts.parts[0].recurse() if parts else midi.flat.notes
            except:
                notes_to_parse = midi.flat.notes
            for element in notes_to_parse:
                if isinstance(element, note.Note):
                    notes.append(str(element.pitch))
                elif isinstance(element, chord.Chord):
                    notes.append('.'.join(str(n) for n in element.pitches))
    return notes

def prepare_sequences(notes, sequence_length=100):
    unique_notes = sorted(set(notes))
    note_to_int = dict((note, number) for number, note in enumerate(unique_notes))
    
    sequences = []
    for i in range(len(notes) - sequence_length):
        seq_in = notes[i:i + sequence_length]
        sequences.append([note_to_int[n] for n in seq_in])

    X = np.array(sequences)
    X = np.reshape(X, (X.shape[0], X.shape[1], 1))  # Reshape for LSTM
    X = X / float(len(unique_notes))  # Normalize input
    return X, note_to_int, unique_notes

# Load and preprocess data
notes = load_midi_files(midi_folder_path)
X, note_to_int, unique_notes = prepare_sequences(notes, sequence_length)
print(f"Loaded {len(notes)} notes.")
print(f"Unique notes: {len(unique_notes)}")
print(f"Number of sequences: {X.shape[0]}")


#Building a model 

from keras.models import Sequential
from keras.layers import LSTM, Dense, Dropout

def create_model(input_shape, num_classes):
    model = Sequential()
    model.add(LSTM(256, input_shape=input_shape, return_sequences=True))
    model.add(Dropout(0.3))
    model.add(LSTM(256, return_sequences=False))
    model.add(Dropout(0.3))
    model.add(Dense(256, activation='relu'))
    model.add(Dense(num_classes, activation='softmax'))
    return model

input_shape = (X.shape[1], X.shape[2])
model = create_model(input_shape, len(unique_notes))
model.compile(loss='categorical_crossentropy', optimizer='adam')



y = np.array([note_to_int[n] for n in notes[sequence_length:]])
y = to_categorical(y, num_classes=len(unique_notes))

# Train the model
model.fit(X, y, epochs=50, batch_size=32, verbose=1)

# Save the trained model
model_path = r"C:\Users\sg\Downloads\Music Generation Process\Trained model\keras.h5"
model.save(model_path)
print("Model trained and saved.")



#Generating music 

from keras.models import load_model
from music21 import stream

model = load_model(model_path)

def generate_notes(model, note_to_int, unique_notes, sequence_length=100, num_generate=500):
    int_to_note = {num: note for note, num in note_to_int.items()}
    start_index = np.random.randint(0, len(X) - 1)
    pattern = X[start_index].flatten().tolist()  # Flatten and convert to list
    generated_notes = []

    for _ in range(num_generate):
        prediction_input = np.reshape(pattern, (1, sequence_length, 1))  # Ensure correct shape
        prediction_input = prediction_input / float(len(unique_notes))
        prediction = model.predict(prediction_input, verbose=0)
        index = np.argmax(prediction)
        result = int_to_note[index]
        generated_notes.append(result)
        pattern.append(index)
        pattern = pattern[1:]  # Ensure pattern length remains constant

    return generated_notes


generated_notes = generate_notes(model, note_to_int, unique_notes, sequence_length, num_generate=500)


#converting it into MIDI file 

def create_midi_from_notes(notes, output_path="output.mid"):
    output_notes = []
    offset = 0
    
    for note_str in notes:
        if '.' in note_str or note_str.isdigit():
            notes_in_chord = note_str.split('.')
            notes_in_chord = [note.Note(n) if not n.isdigit() else note.Note(int(n)) for n in notes_in_chord]
            new_chord = chord.Chord(notes_in_chord)
            new_chord.offset = offset
            output_notes.append(new_chord)
        else:
            new_note = note.Note(note_str)
            new_note.offset = offset
            output_notes.append(new_note)
        offset += 0.5
    
    midi_stream = stream.Stream(output_notes)
    midi_stream.write('midi', fp=output_path)

output_path = r"C:\Users\sg\Downloads\Music Generation Process\generated_music.mid"
create_midi_from_notes(generated_notes, output_path)
print(f"Music generated and saved to {output_path}")



























